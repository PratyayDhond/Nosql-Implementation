char * Encrypt(char * str);
char * Decrypt(char * str);

int getLength(char * str);
char getch();