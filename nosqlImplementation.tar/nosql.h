//error codes
#define INVALID_SYNTAX 0

void noSQLMenu();
